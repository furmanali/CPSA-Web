-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2014 at 10:56 AM
-- Server version: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `hits_counter`
--

DROP TABLE IF EXISTS `hits_counter`;
CREATE TABLE IF NOT EXISTS `hits_counter` (
`id` int(11) NOT NULL,
  `users_credentials_id` int(11) DEFAULT NULL,
  `hits_available` int(11) DEFAULT NULL,
  `hits_success` int(11) NOT NULL,
  `hits_failure` int(11) NOT NULL,
  `counter_total` int(11) DEFAULT NULL,
  `counter_consecutive_failed` int(11) DEFAULT NULL,
  `date_of_expiry` datetime DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `hits_counter`
--

INSERT INTO `hits_counter` (`id`, `users_credentials_id`, `hits_available`, `hits_success`, `hits_failure`, `counter_total`, `counter_consecutive_failed`, `date_of_expiry`) VALUES
(1, 1, 21, 14, 22, 345, 0, '2014-11-27 00:00:00'),
(2, 6, NULL, 0, 0, NULL, NULL, '2014-11-25 00:00:00'),
(3, 7, NULL, 0, 0, NULL, NULL, '2014-11-25 00:00:00'),
(4, 8, NULL, 0, 0, NULL, NULL, '2014-11-25 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `hits_logs`
--

DROP TABLE IF EXISTS `hits_logs`;
CREATE TABLE IF NOT EXISTS `hits_logs` (
`id` int(11) NOT NULL,
  `users_credentials_id` int(11) DEFAULT NULL,
  `authkey` varchar(255) DEFAULT NULL,
  `x2license` varchar(255) DEFAULT NULL,
  `google_drive_template_id` varchar(255) DEFAULT NULL,
  `google_printer_id` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `hits_logs`
--

INSERT INTO `hits_logs` (`id`, `users_credentials_id`, `authkey`, `x2license`, `google_drive_template_id`, `google_printer_id`, `ip`, `email`, `status`, `date_created`) VALUES
(1, NULL, 'test', 'test', 'sad', 'sad', '', '', NULL, '0000-00-00 00:00:00'),
(2, NULL, 'asd', 'asd', 'asd', 'asd`', 'asd', 'asd', NULL, '0000-00-00 00:00:00'),
(3, NULL, 'c26e72f0474c8d9ae02ab692f3596d6f', '123456', NULL, NULL, '127.0.0.1', NULL, 0, NULL),
(4, NULL, 'c26e72f0474c8d9ae02ab692f3596d6f', 'google_printer_id', NULL, NULL, '127.0.0.1', NULL, 0, NULL),
(5, 1, 'c26e72f0474c8d9ae02ab692f3596d6f', '123456', 'google_drive_template_id', 'google_printer_id', '127.0.0.1', NULL, 1, NULL),
(6, 1, 'c26e72f0474c8d9ae02ab692f3596d6f', '123456', 'google_drive_template_id', 'dcf281df-7cfb-ebd6-b903-30d3fa2d05d7', '127.0.0.1', NULL, 1, NULL),
(7, 1, 'c26e72f0474c8d9ae02ab692f3596d6f', '123456', 'google_drive_template_id', 'dcf281df-7cfb-ebd6-b903-30d3fa2d05d7', '127.0.0.1', NULL, 1, '2014-11-24 15:55:27'),
(8, 1, 'c26e72f0474c8d9ae02ab692f3596d6f', '123456', 'google_drive_template_id', '22dcf281df-7cfb-ebd6-b903-30d3fa2d05d7', '127.0.0.1', NULL, 0, '2014-11-24 15:55:44'),
(9, 1, 'c26e72f0474c8d9ae02ab692f3596d6f', '123456', 'google_drive_template_id', 'dcf281df-7cfb-ebd6-b903-30d3fa2d05d7', '127.0.0.1', NULL, 1, '2014-11-24 16:05:05'),
(10, 1, 'c26e72f0474c8d9ae02ab692f3596d6f', '123456', 'google_drive_template_id', 'dcf281df-7cfb-ebd6-b903-30d3fa2d05d7', '127.0.0.1', NULL, 1, '2014-11-24 17:11:50'),
(11, 1, 'c26e72f0474c8d9ae02ab692f3596d6f', '123456', 'google_drive_template_id', 'dcf281df-7cfb-ebd6-b903-30d3fa2d05d7', '127.0.0.1', NULL, 1, '2014-11-24 17:12:35');

-- --------------------------------------------------------

--
-- Table structure for table `shared_google_drive_templates`
--

DROP TABLE IF EXISTS `shared_google_drive_templates`;
CREATE TABLE IF NOT EXISTS `shared_google_drive_templates` (
`id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `gid` varchar(255) DEFAULT NULL,
  `shared_google_printers_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `shared_google_printers`
--

DROP TABLE IF EXISTS `shared_google_printers`;
CREATE TABLE IF NOT EXISTS `shared_google_printers` (
`id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `gid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `subscription`
--

DROP TABLE IF EXISTS `subscription`;
CREATE TABLE IF NOT EXISTS `subscription` (
`id` int(11) NOT NULL,
  `sub_name` varchar(255) DEFAULT NULL,
  `hits_allowed` int(11) DEFAULT NULL,
  `price` decimal(10,0) DEFAULT NULL,
  `durations_in_days` double DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `subscription`
--

INSERT INTO `subscription` (`id`, `sub_name`, `hits_allowed`, `price`, `durations_in_days`, `date_created`, `date_modified`) VALUES
(1, 'test123', 10, '10', 30, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'sad', 10, '0', 30, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'asd', 10, '0', 30, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, '21323213', 10, '0', 30, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, '3123213213213', 10, '0', 30, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'sadasdasda', 10, '0', 30, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'sdasdasdasd', 10, '0', 30, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'asdasdasdsadasd', 10, '0', 30, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 'sadasaaaaaaaaaaaa', 10, '0', 30, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 'ddddddddddddddddddddddd', 10, '0', 30, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 'ddddddddddddddddddddddd', 10, '0', 30, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `subscription_log`
--

DROP TABLE IF EXISTS `subscription_log`;
CREATE TABLE IF NOT EXISTS `subscription_log` (
`id` int(11) NOT NULL,
  `users_credentials_id` int(11) DEFAULT NULL,
  `subscription_id` int(11) DEFAULT NULL,
  `sub_name` varchar(255) DEFAULT NULL,
  `hits_allowed` varchar(255) DEFAULT NULL,
  `durations_in_days` double DEFAULT NULL,
  `price` decimal(10,0) DEFAULT NULL,
  `purchase_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users_credentials`
--

DROP TABLE IF EXISTS `users_credentials`;
CREATE TABLE IF NOT EXISTS `users_credentials` (
`id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `authkey` varchar(255) DEFAULT NULL,
  `x2license` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `date_of_expiry` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `users_credentials`
--

INSERT INTO `users_credentials` (`id`, `email`, `password`, `authkey`, `x2license`, `status`, `date_created`, `date_modified`, `date_of_expiry`) VALUES
(1, 'furman.ali@rolustech.com', 'e10adc3949ba59abbe56e057f20f883e', '123456', '123456', 1, NULL, NULL, '2014-11-27'),
(2, 'asfdas', 'dasdfasdf', NULL, NULL, NULL, NULL, NULL, '2014-11-25'),
(3, 'asif@email.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, NULL, 1, NULL, NULL, '2014-11-25'),
(4, 'ahmed@email.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, NULL, NULL, NULL, NULL, '2014-11-25'),
(5, 'zaheer@email.com', '$2a$10$5.ld32NX4a8edTbSWR3R6ekbL.dZCK8OWfXgaer/.RrZebhSAPJSe', NULL, NULL, NULL, NULL, NULL, '2014-11-25'),
(6, 'furman.ali2@rolustech.com', '$2P3/lU8fzLJk', NULL, NULL, 1, NULL, NULL, '2014-11-25'),
(7, 'ali@email.com', '$2P3/lU8fzLJk', NULL, NULL, 1, NULL, NULL, '2014-11-25'),
(8, 'kamal@email.com', '$2lH9Bbg1vo/g', 'be0cc72d9d80342731d289bf6500df71', '$2XATcZtTUz1U2e8343089a2140e5163ed0202f635072', 1, NULL, NULL, '2014-11-25');

-- --------------------------------------------------------

--
-- Table structure for table `users_details`
--

DROP TABLE IF EXISTS `users_details`;
CREATE TABLE IF NOT EXISTS `users_details` (
`id` int(11) NOT NULL,
  `users_credentials_id` int(11) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `postalcode` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` tinyint(4) DEFAULT NULL,
  `current_subscription_id` int(11) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `users_details`
--

INSERT INTO `users_details` (`id`, `users_credentials_id`, `first_name`, `last_name`, `phone`, `address`, `city`, `state`, `postalcode`, `country`, `company_name`, `dob`, `gender`, `current_subscription_id`) VALUES
(1, 1, 'furman', 'ali', '123456', 'asdfa123', 'lahore', 'punjab', '54000', 'pakistan', 'rolustech', '2014-03-20', 1, 1),
(2, 1, 'furman', 'ali', '123456', 'asdfa123', 'lahore', 'punjab', '54000', 'pakistan', 'rolustech', '2014-03-20', 1, 1),
(3, 1, 'furman', 'ali', '123456', 'asdfa123', 'lahore', 'punjab', '54000', 'pakistan', 'rolustech', '2014-03-20', 1, 1),
(4, 1, 'furman', 'ali', '123456', 'asdfa123', 'lahore', 'punjab', '54000', 'pakistan', 'rolustech', '2014-03-20', 1, 1),
(5, 1, 'furman', 'ali', '123456', 'asdfa123', 'lahore', 'punjab', '54000', 'pakistan', 'rolustech', '2014-03-20', 1, 1),
(6, 1, 'furman', 'ali', '123456', 'asdfa123', 'lahore', 'punjab', '54000', 'pakistan', 'rolustech', '2014-03-20', 1, 1),
(7, 1, 'furman', 'ali', '123456', 'asdfa123', 'lahore', 'punjab', '54000', 'pakistan', 'rolustech', '2014-03-20', 1, 1),
(8, 1, 'furman', 'ali', '123456', 'asdfa123', 'lahore', 'punjab', '54000', 'pakistan', 'rolustech', '2014-03-20', 1, 1),
(9, 1, 'furman', 'ali', '123456', 'asdfa123', 'lahore', 'punjab', '54000', 'pakistan', 'rolustech', '2014-03-20', 1, 1),
(10, 1, 'furman', 'ali', '123456', 'asdfa123', 'lahore', 'punjab', '54000', 'pakistan', 'rolustech', '2014-03-20', 1, 1),
(11, 1, 'furman', 'ali', '123456', 'asdfa123', 'lahore', 'punjab', '54000', 'pakistan', 'rolustech', '2014-03-20', 1, 1),
(12, 1, 'furman', 'ali', '123456', 'asdfa123', 'lahore', 'punjab', '54000', 'pakistan', 'rolustech', '2014-03-20', 1, 1),
(13, 1, 'furman', 'ali', '123456', 'asdfa123', 'lahore', 'punjab', '54000', 'pakistan', 'rolustech', '2014-03-20', 1, 1),
(14, 1, 'furman', 'ali', '123456', 'asdfa123', 'lahore', 'punjab', '54000', 'pakistan', 'rolustech', '2014-03-20', 1, 1),
(15, 1, 'furman', 'ali', '123456', 'asdfa123', 'lahore', 'punjab', '54000', 'pakistan', 'rolustech', '2014-03-20', 1, 1),
(16, NULL, '', '', '', '', '', '', '', '', '', '0000-00-00', NULL, NULL),
(17, NULL, '', '', '', '', '', '', '', '', '', '0000-00-00', NULL, NULL),
(18, NULL, '', '', '', '', '', '', '', '', '', '0000-00-00', NULL, NULL),
(19, 2, 'asdf', 'asdf', 'asdf', '', '', '', '', '', 'asdf', '0000-00-00', NULL, NULL),
(20, 3, 'asif', 'kaleem', '123456', '', '', '', '', '', 'testCompany', '0000-00-00', NULL, NULL),
(21, 4, 'ahmed', 'ali', '123456', 'M.town', 'lahore', 'punjab', '54000', 'pakistan', 'testcom', NULL, 1, NULL),
(22, 5, 'zaheer', 'ali', '123456', '', '', '', '', '', 'testCompany', NULL, NULL, NULL),
(23, 6, 'zaheer', 'ali', '123456', '', '', '', '', '', 'testCompany', NULL, NULL, NULL),
(24, 7, 'ali', 'siraj', '123456', '', '', '', '', '', 'testCompany', NULL, NULL, NULL),
(25, 8, 'kamal', 'athar', '123456', '', '', '', '', '', 'testCompany', NULL, 1, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hits_counter`
--
ALTER TABLE `hits_counter`
 ADD PRIMARY KEY (`id`), ADD KEY `users_credentials_id` (`users_credentials_id`);

--
-- Indexes for table `hits_logs`
--
ALTER TABLE `hits_logs`
 ADD PRIMARY KEY (`id`), ADD KEY `users_credentials_id` (`users_credentials_id`);

--
-- Indexes for table `shared_google_drive_templates`
--
ALTER TABLE `shared_google_drive_templates`
 ADD PRIMARY KEY (`id`), ADD KEY `shared_google_printers_id` (`shared_google_printers_id`);

--
-- Indexes for table `shared_google_printers`
--
ALTER TABLE `shared_google_printers`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription`
--
ALTER TABLE `subscription`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription_log`
--
ALTER TABLE `subscription_log`
 ADD PRIMARY KEY (`id`), ADD KEY `users_credentials_id` (`users_credentials_id`), ADD KEY `subscription_id` (`subscription_id`);

--
-- Indexes for table `users_credentials`
--
ALTER TABLE `users_credentials`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_details`
--
ALTER TABLE `users_details`
 ADD PRIMARY KEY (`id`), ADD KEY `users_credentials_id` (`users_credentials_id`), ADD KEY `FK_USERSDETAILS_SUBSCRIPTION` (`current_subscription_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hits_counter`
--
ALTER TABLE `hits_counter`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `hits_logs`
--
ALTER TABLE `hits_logs`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `shared_google_drive_templates`
--
ALTER TABLE `shared_google_drive_templates`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `shared_google_printers`
--
ALTER TABLE `shared_google_printers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `subscription`
--
ALTER TABLE `subscription`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `subscription_log`
--
ALTER TABLE `subscription_log`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users_credentials`
--
ALTER TABLE `users_credentials`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `users_details`
--
ALTER TABLE `users_details`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `hits_counter`
--
ALTER TABLE `hits_counter`
ADD CONSTRAINT `hits_counter_ibfk_1` FOREIGN KEY (`users_credentials_id`) REFERENCES `users_credentials` (`id`);

--
-- Constraints for table `hits_logs`
--
ALTER TABLE `hits_logs`
ADD CONSTRAINT `hits_logs_ibfk_1` FOREIGN KEY (`users_credentials_id`) REFERENCES `users_credentials` (`id`);

--
-- Constraints for table `shared_google_drive_templates`
--
ALTER TABLE `shared_google_drive_templates`
ADD CONSTRAINT `shared_google_drive_templates_ibfk_1` FOREIGN KEY (`shared_google_printers_id`) REFERENCES `shared_google_printers` (`id`);

--
-- Constraints for table `subscription_log`
--
ALTER TABLE `subscription_log`
ADD CONSTRAINT `subscription_log_ibfk_1` FOREIGN KEY (`users_credentials_id`) REFERENCES `users_credentials` (`id`),
ADD CONSTRAINT `subscription_log_ibfk_2` FOREIGN KEY (`subscription_id`) REFERENCES `subscription` (`id`);

--
-- Constraints for table `users_details`
--
ALTER TABLE `users_details`
ADD CONSTRAINT `users_details_ibfk_1` FOREIGN KEY (`users_credentials_id`) REFERENCES `users_credentials` (`id`) ON UPDATE NO ACTION,
ADD CONSTRAINT `users_details_ibfk_2` FOREIGN KEY (`current_subscription_id`) REFERENCES `subscription` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
